#ifndef _NGX_HTTP_VOD_STATUS_H_INCLUDED_
#define _NGX_HTTP_VOD_STATUS_H_INCLUDED_

// includes
#include <ngx_http.h>

// functions
ngx_int_t ngx_http_vod_status_handler(ngx_http_request_t *r);

#endif // _NGX_HTTP_VOD_STATUS_H_INCLUDED_
